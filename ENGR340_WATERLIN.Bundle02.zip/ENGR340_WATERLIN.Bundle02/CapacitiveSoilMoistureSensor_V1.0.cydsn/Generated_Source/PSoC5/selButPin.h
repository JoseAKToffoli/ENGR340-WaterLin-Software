/*******************************************************************************
* File Name: selButPin.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_selButPin_H) /* Pins selButPin_H */
#define CY_PINS_selButPin_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "selButPin_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 selButPin__PORT == 15 && ((selButPin__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    selButPin_Write(uint8 value);
void    selButPin_SetDriveMode(uint8 mode);
uint8   selButPin_ReadDataReg(void);
uint8   selButPin_Read(void);
void    selButPin_SetInterruptMode(uint16 position, uint16 mode);
uint8   selButPin_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the selButPin_SetDriveMode() function.
     *  @{
     */
        #define selButPin_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define selButPin_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define selButPin_DM_RES_UP          PIN_DM_RES_UP
        #define selButPin_DM_RES_DWN         PIN_DM_RES_DWN
        #define selButPin_DM_OD_LO           PIN_DM_OD_LO
        #define selButPin_DM_OD_HI           PIN_DM_OD_HI
        #define selButPin_DM_STRONG          PIN_DM_STRONG
        #define selButPin_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define selButPin_MASK               selButPin__MASK
#define selButPin_SHIFT              selButPin__SHIFT
#define selButPin_WIDTH              1u

/* Interrupt constants */
#if defined(selButPin__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in selButPin_SetInterruptMode() function.
     *  @{
     */
        #define selButPin_INTR_NONE      (uint16)(0x0000u)
        #define selButPin_INTR_RISING    (uint16)(0x0001u)
        #define selButPin_INTR_FALLING   (uint16)(0x0002u)
        #define selButPin_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define selButPin_INTR_MASK      (0x01u) 
#endif /* (selButPin__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define selButPin_PS                     (* (reg8 *) selButPin__PS)
/* Data Register */
#define selButPin_DR                     (* (reg8 *) selButPin__DR)
/* Port Number */
#define selButPin_PRT_NUM                (* (reg8 *) selButPin__PRT) 
/* Connect to Analog Globals */                                                  
#define selButPin_AG                     (* (reg8 *) selButPin__AG)                       
/* Analog MUX bux enable */
#define selButPin_AMUX                   (* (reg8 *) selButPin__AMUX) 
/* Bidirectional Enable */                                                        
#define selButPin_BIE                    (* (reg8 *) selButPin__BIE)
/* Bit-mask for Aliased Register Access */
#define selButPin_BIT_MASK               (* (reg8 *) selButPin__BIT_MASK)
/* Bypass Enable */
#define selButPin_BYP                    (* (reg8 *) selButPin__BYP)
/* Port wide control signals */                                                   
#define selButPin_CTL                    (* (reg8 *) selButPin__CTL)
/* Drive Modes */
#define selButPin_DM0                    (* (reg8 *) selButPin__DM0) 
#define selButPin_DM1                    (* (reg8 *) selButPin__DM1)
#define selButPin_DM2                    (* (reg8 *) selButPin__DM2) 
/* Input Buffer Disable Override */
#define selButPin_INP_DIS                (* (reg8 *) selButPin__INP_DIS)
/* LCD Common or Segment Drive */
#define selButPin_LCD_COM_SEG            (* (reg8 *) selButPin__LCD_COM_SEG)
/* Enable Segment LCD */
#define selButPin_LCD_EN                 (* (reg8 *) selButPin__LCD_EN)
/* Slew Rate Control */
#define selButPin_SLW                    (* (reg8 *) selButPin__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define selButPin_PRTDSI__CAPS_SEL       (* (reg8 *) selButPin__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define selButPin_PRTDSI__DBL_SYNC_IN    (* (reg8 *) selButPin__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define selButPin_PRTDSI__OE_SEL0        (* (reg8 *) selButPin__PRTDSI__OE_SEL0) 
#define selButPin_PRTDSI__OE_SEL1        (* (reg8 *) selButPin__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define selButPin_PRTDSI__OUT_SEL0       (* (reg8 *) selButPin__PRTDSI__OUT_SEL0) 
#define selButPin_PRTDSI__OUT_SEL1       (* (reg8 *) selButPin__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define selButPin_PRTDSI__SYNC_OUT       (* (reg8 *) selButPin__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(selButPin__SIO_CFG)
    #define selButPin_SIO_HYST_EN        (* (reg8 *) selButPin__SIO_HYST_EN)
    #define selButPin_SIO_REG_HIFREQ     (* (reg8 *) selButPin__SIO_REG_HIFREQ)
    #define selButPin_SIO_CFG            (* (reg8 *) selButPin__SIO_CFG)
    #define selButPin_SIO_DIFF           (* (reg8 *) selButPin__SIO_DIFF)
#endif /* (selButPin__SIO_CFG) */

/* Interrupt Registers */
#if defined(selButPin__INTSTAT)
    #define selButPin_INTSTAT            (* (reg8 *) selButPin__INTSTAT)
    #define selButPin_SNAP               (* (reg8 *) selButPin__SNAP)
    
	#define selButPin_0_INTTYPE_REG 		(* (reg8 *) selButPin__0__INTTYPE)
#endif /* (selButPin__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_selButPin_H */


/* [] END OF FILE */
