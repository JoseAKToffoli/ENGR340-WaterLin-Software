/*******************************************************************************
* File Name: selButPinOut.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_selButPinOut_H) /* Pins selButPinOut_H */
#define CY_PINS_selButPinOut_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "selButPinOut_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 selButPinOut__PORT == 15 && ((selButPinOut__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    selButPinOut_Write(uint8 value);
void    selButPinOut_SetDriveMode(uint8 mode);
uint8   selButPinOut_ReadDataReg(void);
uint8   selButPinOut_Read(void);
void    selButPinOut_SetInterruptMode(uint16 position, uint16 mode);
uint8   selButPinOut_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the selButPinOut_SetDriveMode() function.
     *  @{
     */
        #define selButPinOut_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define selButPinOut_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define selButPinOut_DM_RES_UP          PIN_DM_RES_UP
        #define selButPinOut_DM_RES_DWN         PIN_DM_RES_DWN
        #define selButPinOut_DM_OD_LO           PIN_DM_OD_LO
        #define selButPinOut_DM_OD_HI           PIN_DM_OD_HI
        #define selButPinOut_DM_STRONG          PIN_DM_STRONG
        #define selButPinOut_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define selButPinOut_MASK               selButPinOut__MASK
#define selButPinOut_SHIFT              selButPinOut__SHIFT
#define selButPinOut_WIDTH              1u

/* Interrupt constants */
#if defined(selButPinOut__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in selButPinOut_SetInterruptMode() function.
     *  @{
     */
        #define selButPinOut_INTR_NONE      (uint16)(0x0000u)
        #define selButPinOut_INTR_RISING    (uint16)(0x0001u)
        #define selButPinOut_INTR_FALLING   (uint16)(0x0002u)
        #define selButPinOut_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define selButPinOut_INTR_MASK      (0x01u) 
#endif /* (selButPinOut__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define selButPinOut_PS                     (* (reg8 *) selButPinOut__PS)
/* Data Register */
#define selButPinOut_DR                     (* (reg8 *) selButPinOut__DR)
/* Port Number */
#define selButPinOut_PRT_NUM                (* (reg8 *) selButPinOut__PRT) 
/* Connect to Analog Globals */                                                  
#define selButPinOut_AG                     (* (reg8 *) selButPinOut__AG)                       
/* Analog MUX bux enable */
#define selButPinOut_AMUX                   (* (reg8 *) selButPinOut__AMUX) 
/* Bidirectional Enable */                                                        
#define selButPinOut_BIE                    (* (reg8 *) selButPinOut__BIE)
/* Bit-mask for Aliased Register Access */
#define selButPinOut_BIT_MASK               (* (reg8 *) selButPinOut__BIT_MASK)
/* Bypass Enable */
#define selButPinOut_BYP                    (* (reg8 *) selButPinOut__BYP)
/* Port wide control signals */                                                   
#define selButPinOut_CTL                    (* (reg8 *) selButPinOut__CTL)
/* Drive Modes */
#define selButPinOut_DM0                    (* (reg8 *) selButPinOut__DM0) 
#define selButPinOut_DM1                    (* (reg8 *) selButPinOut__DM1)
#define selButPinOut_DM2                    (* (reg8 *) selButPinOut__DM2) 
/* Input Buffer Disable Override */
#define selButPinOut_INP_DIS                (* (reg8 *) selButPinOut__INP_DIS)
/* LCD Common or Segment Drive */
#define selButPinOut_LCD_COM_SEG            (* (reg8 *) selButPinOut__LCD_COM_SEG)
/* Enable Segment LCD */
#define selButPinOut_LCD_EN                 (* (reg8 *) selButPinOut__LCD_EN)
/* Slew Rate Control */
#define selButPinOut_SLW                    (* (reg8 *) selButPinOut__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define selButPinOut_PRTDSI__CAPS_SEL       (* (reg8 *) selButPinOut__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define selButPinOut_PRTDSI__DBL_SYNC_IN    (* (reg8 *) selButPinOut__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define selButPinOut_PRTDSI__OE_SEL0        (* (reg8 *) selButPinOut__PRTDSI__OE_SEL0) 
#define selButPinOut_PRTDSI__OE_SEL1        (* (reg8 *) selButPinOut__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define selButPinOut_PRTDSI__OUT_SEL0       (* (reg8 *) selButPinOut__PRTDSI__OUT_SEL0) 
#define selButPinOut_PRTDSI__OUT_SEL1       (* (reg8 *) selButPinOut__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define selButPinOut_PRTDSI__SYNC_OUT       (* (reg8 *) selButPinOut__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(selButPinOut__SIO_CFG)
    #define selButPinOut_SIO_HYST_EN        (* (reg8 *) selButPinOut__SIO_HYST_EN)
    #define selButPinOut_SIO_REG_HIFREQ     (* (reg8 *) selButPinOut__SIO_REG_HIFREQ)
    #define selButPinOut_SIO_CFG            (* (reg8 *) selButPinOut__SIO_CFG)
    #define selButPinOut_SIO_DIFF           (* (reg8 *) selButPinOut__SIO_DIFF)
#endif /* (selButPinOut__SIO_CFG) */

/* Interrupt Registers */
#if defined(selButPinOut__INTSTAT)
    #define selButPinOut_INTSTAT            (* (reg8 *) selButPinOut__INTSTAT)
    #define selButPinOut_SNAP               (* (reg8 *) selButPinOut__SNAP)
    
	#define selButPinOut_0_INTTYPE_REG 		(* (reg8 *) selButPinOut__0__INTTYPE)
#endif /* (selButPinOut__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_selButPinOut_H */


/* [] END OF FILE */
